Parcher Michaelson
Greg Daniels

Chatbot for Inteligent systems

this is implemented in python 2.7. to run the chatbot symply type "python reply.py".